// $(document).ready(function () {

// $('.box').raindrops({
// color:'#99d4a5',
// canvasHeight:200});

// })

jQuery('.box').raindrops(
{color:'#f77b7b',
canvasHeight:150, 
waveLength: 100,
 rippleSpeed: 0.05, 
density: 0.04});

console.log('working');