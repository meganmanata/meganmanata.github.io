document.getElementById('color-button').onclick = function () {
	console.log('button click')
}